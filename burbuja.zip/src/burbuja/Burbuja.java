/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package burbuja;

import java.io.*;
/**
 * Esta clase sirve para ordenar de forma correcta cada elemento de un array de mayor a menor.
 * 
 * La clase comapara cada uno de los elementos en la lista del array y lo compara con el anterior para saber si
 * su posición en la lista es correcta o no, teniendo en cuenta que el orden correcto es de mayor a menor.
 * 
 * @author a17brandanfr
 */
public class Burbuja
{
/*
    Método main de esta clase.
    */
public static void main(String arg[]) throws IOException
{
    /**
     * Este bloque sirve para crear el array y marcar el tamaño de este
     * tam Marca el tamaño del array
     * arr Crea un array de tipo int
     */
BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
System.out.print("\n Ingrese Numero de Datos a Ingresar : ");
int tam = Integer.parseInt(in.readLine());
int arr[] = new int[tam];

System.out.println();
/**
 * j Sirve para dar un "nombre" a cada posición dentro del array para mostrarla en pantalla.
 * i Sirve para seleccionar cada posición del array a la que vas a asignar un valor.
 */
int j = 0;
for (int i = 0 ; i < arr.length;i++)
{
j+=1;
System.out.print("Elemento " + j + " : ");
arr[i] = Integer.parseInt(in.readLine());
}
burbuja(arr);
}

/**
 * Este método compara cada elemento del array para saber si es mayor que el anterior.
 * La variable tmp almacena el valor de la última posición para compararlo con el siguiente.
 * @param arreglo  Es una variable temporal que sirve para comparar cada elemento de el array con la variable tmp.
 * 
 */

public static void burbuja(int arreglo[])
{
for(int i = 0; i < arreglo.length - 1; i++)
{
for(int j = 0; j < arreglo.length - 1; j++)
{
if (arreglo[j] < arreglo[j + 1])
{
int tmp = arreglo[j+1];
arreglo[j+1] = arreglo[j];
arreglo[j] = tmp;
}
}
}
for(int i = 0;i < arreglo.length; i++)
{
System.out.print(arreglo[i]+"\n");
}
}
}